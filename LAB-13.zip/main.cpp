

#include<iostream>                             
#include<string>                             
using namespace std;                          

enum states {                               
	start, a, b, c, d, e , finish              
};
//((a*|b)c)*de*
bool matrix[finish+1][finish+1] = {
    {0,1,1,1,1,0,0},
    {0,1,0,1,0,0,0},
    {0,0,0,1,0,0,0},
    {0,1,1,1,1,0,0},
    {1,0,0,0,0,1,1},
    {1,0,0,0,0,1,1},
    {0,0,0,0,0,0,0}
};         

bool check(string s) {                 
	int i = 0;                               
	states State = start;                     
	while (i < s.length()) {                   
		char k = s[i];                             
		states variable;                         
		switch (k)                        
		{
		case 'a': { variable = a; break; }       
		case 'b': { variable = b; break; }        
		case 'c': { variable = c; break; }          
		case 'd': { variable = d; break; }          
		case 'e': { variable = e; break; }         
		default: { return false; }                 
		}
		if (matrix[State][variable]==0) return false;
		State = variable;                           
		i++;                                        
	}
	if (!matrix[State][finish]) return false;    
	return true;                                
}

int main() {

  cout << "input a string:";                    
	string s;                                 
	cin >> s;                                  
	cout << "result is:" <<check(s)<<endl;               
}