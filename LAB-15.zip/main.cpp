#include <iostream>                                                   //include file "iostream"
#include <string>                                                     //include file "string"
#include <vector>                                                     //include file "vector"

using namespace std;                                                  //use standard namespace

/*
E→E+T|E-T|T
T→T*F|T/F|F
F→id|num|(E)

1.E → E+T
2.E → E-T
3.E → T
4.T → T*F
5.T → T/F
6.T → F
7.F → (E)
8.F → id
9.F → num
*/
const int shift[17][9] = {                                                    //shift table
	        /* id  num +   -   *   /   (   )   $  */
  /*start*/{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/* E */{ 0,  0,  7,  8,  0,  0,  0,  0,  0 },
		/* T */{ 0,  0,  0,  0,  9,  10, 0,  0,  0 },
		/* F */{ 0,  0,  0,  0,  0,  0,  0,  0,  0 },
		/* ( */{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/* id*/{ 0,  0,  0,  0,  0,  0,  0,  0,  0 },
		/*num*/{ 0,  0,  0,  0,  0,  0,  0,  0,  0 },
		/* + */{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/* - */{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/* * */{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/* / */{ 5,  6,  0,  0,  0,  0,  4,  0,  0 },
		/*   */{ 0,  0,  7,  8,  0,  0,  0,  16, 0 },
		/* + */{ 0,  0,  0,  0,  9,  10, 0,  0,  0 },
		/* - */{ 0,  0,  2,  2,  9,  10, 0,  0,  0 },
		/* * */{ 0,  0,  0,  0,  0,  0,  0,  0,  0 },
		/* / */{ 0,  0,  0,  0,  0,  0,  0,  0,  0 },
		/* ) */{ 0,  0,  0,  0,  0,  0,  0,  0,  0 }
	};

const int reduce[17][9] = {                                                   //reduce table
	  /*      i   n  +  -  *  /  (  )  $     */
	/*start*/{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* E */{ 0, 0, 0, 0, 0, 0, 0, 0, 100 },
		/* T */{ 0, 0, 3, 3, 0, 0, 0, 3, 3 },
		/* F */{ 0, 0, 6, 6, 6, 6, 0, 6, 6 },
		/* ( */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* id*/{ 0, 0, 8, 8, 8, 8, 0, 8, 8 },
		/*num*/{ 0, 0, 9, 9, 9, 9, 0, 9, 9 },
		/* + */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* - */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* * */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* / */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* e */{ 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		/* + */{ 0, 0, 1, 1, 0, 0, 0, 1, 1 },
		/* - */{ 0, 0, 2, 2, 0, 0, 0, 2, 2 },
		/* * */{ 0, 0, 4, 4, 4, 4, 0, 4, 4 },
		/* / */{ 0, 0, 5, 5, 5, 5, 0, 5, 5 },
		/* ) */{ 0, 0, 7, 7, 7, 7, 0, 7, 7 }
	};

int GO_TO[17][3] = {                                                    //GO TO table
	  /*       E  T  F      */
		/* s */{ 1, 2, 3 },
		/* E */{ 0, 0, 0 },
		/* T */{ 0, 0, 0 },
		/* F */{ 0, 0, 0 },
		/* ( */{ 11, 2, 3 },
		/* id*/{ 0, 0, 0 },
		/*num*/{ 0, 0, 0 },
		/* + */{ 0, 12, 3 },
		/* - */{ 0, 13, 3 },
		/* * */{ 0, 0, 14 },
		/* / */{ 0, 0, 15 },
		/*   */{ 0, 0, 0 },
		/* + */{ 0, 0, 0 },
		/* - */{ 0, 0, 0 },
		/* * */{ 0, 0, 0 },
		/* / */{ 0, 0, 0 },
		/* ) */{ 0, 0, 0 }
	};

	vector <int> stack = { 0 };                                         //stack
  int length_of_rules[9] = { 3, 3, 1, 3, 3, 1, 3, 1, 1 };             //array that contains length of rules
 
  
    
bool check(string input){                                             //definion a function that determines whether these tokens form a valid grammar sequence

	bool result = true;                                                 //result of checking
	input.push_back('$');                                               //add '$' to string
	
	while (1) {                                                         //endless cycle
		int i, j;                                                         //definion new integers i and j
		while (input.front() == ' ')                                      //while the 1st element of string is whitespace
			input.erase(0, 1);                                              //delete this whitespace
		i = stack.back();                                                 //i = reference to the last element in the container
		switch (input.front()) {                                          //if the first symbol of string is...
			case 'i': j = 0; break;                                         //'i' then j = 0
			case 'n': j = 1; break;                                         //'n' then j = 1
			case '+': j = 2; break;                                         //'+' then j = 2;
			case '-': j = 3; break;                                         //'-' then j = 3;
			case '*': j = 4; break;                                         //'*' then j = 4
			case '/': j = 5; break;                                         //'/' then j = 5;
			case '(': j = 6; break;                                         //'(' then j = 6;
			case ')': j = 7; break;                                         //')' then j = 7;
			case '$': j = 8; break;                                         //'$' then j = 8;
			default: j = -1; break;                                         //else j = -1
		}
		if (j == -1) {                                                    //if j == -1
			result = false;                                                 //return false
			break;
		}
		//////////////////////////
		
		/////////////////////////
		if (shift[i][j] > 0) {                                            //if a shift is possible
			stack.push_back(shift[i][j]);                                   //add to stack sequence number of shift (1...16)
			if (input.front() == 'i')                                       //if it's the "id"
				input.erase(0, 2);                                            //erace from stack 2 elements
			else if (input.front() == 'n')                                  //if it's the "num"
				input.erase(0, 3);                                            //erase from stack 3 elements
			else                                                            //else
				input.erase(0, 1);                                            //erace from stack 1 element
		///////////////////////////	
		
		///////////////////////////
		}
		else if (reduce[i][j] == 100) {                                   //if access
			break;                                                          //then break
		}
		else if (reduce[i][j] > 0) {                                      //if it is possible to do a reduce
			for (int k = 0; k < length_of_rules[reduce[i][j] -1]; k++)                //delete from stack the number of elements 
				stack.pop_back();                                             //that corresponds the rule 
		
		int index;
		int temp = reduce[i][j] - 1;		
		if (temp >=0 && temp <= 2)
		index = 0;
		if (temp >=3 && temp <= 5)
		index = 1;
		if (temp >=6 && temp <= 8)
		index = 2;
		
		stack.push_back(GO_TO[stack.back()][index]);                      //push to stack reduced operation
		///////////
    
		///////////
		}
		
		else {                                                            //else
			result = false;                                                 //result is false
			break;
		}
		/////////
		for (auto k : stack) cout << k << ' ';
		cout << input << endl << endl;
		///////
	}
	return result;                                                     //return the result
	}
	
	
	
int main()
{
	string input;                                                      //new string named "input"
	cin >> input;                                                      //input this string
	bool result = check(input);                                        //result of the operation check
	cout << "Result is " << result << endl;                            //print the result
	return 0;
/* 
118:
//cout << i << ' ' << j << endl;

127:
//cout << "action " << shift[i][j] << endl;

138:
//cout << "goto " << GO_TO[stack.back()][goto_index[shift[i][j] -1]] << endl;

143-144:
		//for (auto k : stack) cout << k << ' ';
		//cout << input << endl << endl;
*/