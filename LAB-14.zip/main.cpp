/*include files "iostream", "vector", "string"*/
#include <iostream>       
#include <string>        
#include <vector>

using namespace std;        //use standard namespace

int main()
{
	int arr[5][9] = {
	  /*  i 	n 	+	  -	  *	  /	  (	  )	  $   */
/*E*/{  1,  1, -1, -1, -1, -1,  1, -1, -1 },
/*A*/{ -1, -1,  2,  3, -1, -1, -1,  4,  4 },
/*T*/{  5,  5, -1, -1, -1, -1,  5, -1, -1 },
/*B*/{ -1, -1,  8,  8,  6,  7, -1,  8,  8 },
/*F*/{  9, 10, -1, -1, -1, -1, 11, -1, -1 },
	};
    /*
    E→E+T|E-T|T
    T→T*F|T/F|F
    F→id|num|(E)	
    1.E > TA
    2.A > +TA
    3.A > -TA
    4.A > e
    5.T > FB
    6.B > *FB
    7.B > /FB
    8.B > e
    9.F > i
    10.F > n
    11.F > (E)
    */
	string stack = "E$", input;                                                                 //definition of new string
	//"" - пустота
	vector <string> rules = { "TA", "+TA", "-TA", "", "FB", "*FB", "/FB", "", "i", "n", "(E)" };//vector of rules
	bool ans = true;                                                                            //result
	getline(cin, input);                                                                        //input a string
	input.push_back('$');                                                                       //add to string line end character
	//cout << input << endl;
	while (!input.empty()) {                                                                    //while string is not empty
		int i, j;
		while (input.front() == ' ')                                                              //if there are spaces
			input.erase(0, 1);                                                                      //delete spaces
		if (stack.front() == input.front()) {                                                     //if first element of stack is an equal to first element of line
			if (input.front() == 'i')                                                               //if it's the "id"
				input.erase(0, 2);                                                                    //erase 0 and 1st symbols of line
			else                                                                                    //else
				if (input.front() == 'n')                                                             //if it's "num"
					input.erase(0, 3);                                                                  //erace first 3 characters
				else                                                                                  //else
					input.erase(0, 1);                                                                  //go to the next symbol
			stack.erase(0, 1);                                                                      //erase 1st symbol from the stack
			continue;                                                                               //continue
		}
		switch (input.front()) {                                                                  //if the first symbol of string is...
			case 'i': j = 0; break;                                                                 //'i' then j=0
			case 'n': j = 1; break;                                                                 //'n' then j = 1
			case '+': j = 2; break;                                                                 //'+' then j = 2;
			case '-': j = 3; break;                                                                 //'-' then j = 3;
			case '*': j = 4; break;                                                                 //'*' then j = 4
			case '/': j = 5; break;                                                                 //'/' then j = 5
			case '(': j = 6; break;                                                                 //'(' then j = 6
			case ')': j = 7; break;                                                                 //')' then j = 7
			case '$': j = 8; break;                                                                 //'$' then j = 8
			default: j = -1;  break;                                                                //else j = -1
		}
		switch (stack.front()) {                                                                 //if first element of stack is...
			case 'E': i = 0; break;                                                                //if it's an E then i = 0
			case 'A': i = 1; break;                                                                //if it's an E' then i = 1
			case 'T': i = 2; break;                                                                //if it's a T then i = 2
			case 'B': i = 3; break;                                                                //if it's a T' then i = 3
			case 'F': i = 4; break;                                                                //if it's a F then i = 4
			default: i = -1; break;                                                                //else i = -1
		}
		if ((i == -1) || (j == -1) || (arr[i][j] == -1)) {                                      //if i==-1 or j==-1 or element in the matrix is an equal to -1
			ans = false;                                                                          //return false
			break;
		}
		stack.erase(0, 1);                                                                      //erace from stack the first element
		stack = rules[arr[i][j] - 1] + stack;                                                   //add to stack rule
	  cout << stack <<' '<< input << endl;
	}
	cout << "result is " << ans << endl;

	return 0;
}

/*
E→E+T|E-T|T
T→T*F|T/F|F
F→id|num|(E)
1.E > TA
2.A > +TA
3.A > -TA
4.A > e
5.T > FB
6.B > *FB
7.B > /FB
8.B > e
9.F > i
10.F > n
11.F > (E)
*/
