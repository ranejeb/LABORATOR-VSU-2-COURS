#include "List.h"

Element::Element(int value) { this->val = value; }                              //create new element


Element::~Element()                                                             //delete element
{
  if (next != nullptr)                                                          //if the next element is exists
	{
		next.reset();                                                               //reduce the number of references to the object
	}
		cout << "Значение" << this->val << " было удалено из списка." << endl;      //print the message
}
                                                                                //next.use_count()


void List::insert(int val)                                                    //insert new element
{
  shared_ptr<Element> newOne(new Element(val));                               //create new pointer newOne

	if (Last.lock() != nullptr) {                                               //if Last element is exists
		newOne->prev = Last;                                                      //for new element prev element is Last
		newOne->next = Last.lock()->next;                                         //for new element next is next for last element
		Last.lock()->next->prev = newOne;                                         //prev for Last.lock()->next is newOne
		Last.lock()->next = newOne;                                               //next for Last.lock() is newOne
	}
	//Last.lock() creates new shared_ptr that shares ownership of the managed object
	else
	{
		newOne->prev = newOne;                                                    //prev for newOne is newOne
		newOne->next = newOne;                                                    //next for newOne is newOne
	}

	Last = newOne;                                                              //last element is newOne
}

shared_ptr<Element> List::First(int val)
{
  if (Last.lock() != nullptr)                                               //if last element exists
	{
		auto node = Last.lock();                                                //create new pointer on last element

		do
		{                                                                       //while node points on the last element
			if (node->val == val) return node;                                    //if value of element is equal to val

			node = node->next;                                                    //go to next element
		} while (node != Last.lock());
	}

	return nullptr;
}

void List::remove(int val)                                                  //remove value from list
{
	auto node = First(val);                                                   //create new pointer on the First element

	if (node)                                                                //if element exists
	{
		node->next->prev = node->prev;
		node->prev.lock()->next = node->next;

		if (node == Last.lock())                                                //if this element is last
		{
			Last = node->prev;                                                    //last element is prev for this element
		}

		node.reset();                                                           //reduce the number of references to the object
	}
}

List::~List()                                                               //delete object
{
  	if (!Last.expired())                                                   //checks to see if the object referenced by weak_ptr was not deleted
	{
		Last.lock()->next.reset();                                            //reduce the number of references to the next
		Last.reset();                                                         //reduce the number of references to the last
	}

}