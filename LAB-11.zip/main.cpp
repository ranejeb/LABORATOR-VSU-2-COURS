#include <iostream>
#include "List.h"

using namespace std;

int main() {
  
  List list;
  

  list.insert(4);
  list.insert(5);
  list.insert(9);
  list.insert(1);
  
  list.remove(1);

	return 0;
}