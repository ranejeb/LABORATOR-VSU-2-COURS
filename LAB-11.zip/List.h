#include <iostream>
#include <memory>
#include <stdlib.h>
using namespace std;  

	struct Element {                        //declaration of structure
		int val;                              //value of element
		weak_ptr<Element> prev;               //pointer on previous elements
		shared_ptr<Element> next;             //pointer on next elements
		Element(int value);                   //set value
	  ~Element();
	};
	
class List {                              //declaration of the class
  public:
	shared_ptr<Element> First(int);         //pointer on first element
	weak_ptr<Element> Last;                 //pointer on last element
	
	List(){};                               //constructor
	~List();                                //destructor
	void insert(int val);                   //insert new element
	void remove(int val);                   //remove element
};