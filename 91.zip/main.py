#Оформите разработанные функции в отдельном модуле. Напишите программу демонстрирующую работу функций, импортированных из этого модуля. (Всех функций в модуле)

import module as m                                            #import module.py and name it                                                               as m


print("Задание 1: НОД для двух чисел \n Введите два числа");  #print the message
a = abs(int(input())); b = abs(int(input()))			            #input a, b strings and                                                                     convert it to int
print("НОД для чисел равен",m.NOD(a,b))                       #print the message

print("Задание 2: НОД для нескольких чисел \n Введите количество параметров")
number = abs(int(input())); i = 0; A = []
while i<number:
  print("Введите число:")
  a = abs(int(input()))
  A.append(a)
  i+=1
print("НОД для чисел равен", m.NODUNLIM(*A),'\n')


print("Задание 3: нахождение всех простых делителей числа \n Введите число:")
z = abs(int(input()))
print("Простые делители числа", z, 'равны:')
X = m.DIV(z)
print(X)


print("Задание 4: декоратор. Введите n числа ")
n=int(input("Введите количество "))
L = []
i=0
while i<n:
  print("Введите число:")
  a = abs(int(input()))              #абсолютная величина целочисленного ввода
  L.append(a)                        #добавление в список
  i+=1                               #счетчик
print('Сумма равна', m.sum(*L));
print('Произведение равно', m.mul(*L));


num=m.NODNUM(m.NOD)
print("НОД чисел 20, 30, 40, 50 равен",num(20,30,40,50));