
#1 Напишите функцию вычисления наибольшего общего делителя с помощью алгоритма Евклида.
def NOD(x,y):               #declaration of NOD function
    while x!=0 and y!=0:    #while x and y is not equal to null
        if x>y:             #if x>y do
            x=x%y           #x = remainder of dividing x by y
        else:               #else do
            y=y%x           #y = remainder of dividing y by x
    return x+y              #return the result
          
#2 "ASD" Модифицируйте функцию из задания 1 так, чтобы она работала с произвольным количеством параметров.
def NODUNLIM(*args):        #declaration of NODUNLIM function
    a=args[0]               #a = the first argument
    for i in args:          #for all arguments
        a=NOD(a,i)          #calculate NOD for a and next for a element
    return a                #return the result

#3 Напишите функцию поочередно возвращающую все простые делители данного числа.
def DIV(n):
   i = 2
   A = set()
   while i * i <= n:
       while n % i == 0:
           A.add(int(i))   #добавление элементов список множеста
           n = int(n / i)
       i = i + 1
   if n > 1:
       A.add(n)
   A=sorted(A)
   return A
   

#4Напишите функцию-декоратор, которая позволяет из функции f, принимающей 2 аргумента, получить функцию принимающую произвольное количество аргументов, выполняющую свертку последовательности своих аргументов с помощью функции f.
def NODNUM(func):                     
    def start(*args):                    #передаем нейкое количество аргументов(не ключевых)
        a=args[0]                        #начальный элемент
        for i in range(len(args)-1):     
            a=func(a,args[i+1]) 
        return a 
    return start

#Если нужно продекорировать функцию, объявляется @имя_декоратора перед функцией, которую надо продекорировать, и т.о. она подставляется в код вместо func

@NODNUM  
def sum(a,b):   
    return a+b 

@NODNUM    
def mul(a,b):  
    return a*b 