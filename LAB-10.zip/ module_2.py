class Factory:
  Class Factory contains:
  -Fields:
      Name of Factory
      Type of Factory
      Resources that Factory uses/provides
  -Methods
      __init__(Name,Type,Resources)
      __del__
      changeResources(self, NameOfResource, Value) - change value of the resourse NameOfResource by Value
      DeleteResources(self, NameOfResource) - delete the resourse NameOfResource
  _Name = ""
  Type = ""
  Resources = ""

  def __init__(self, GName, res):                                                                         #declaration of method
      Method sets Name, Type and resources of Factory:
      GName - Name of Factory
      GType - Type of Factory ('Resource' (provides) /'Factory' (uses))
      res - Dict with NameOfResource:Value
      self.Name = GName                                                                                   #field Name = GName
      self.Resources = {i: res[i] if all([res[i] >= 0, type(res[i]) == int]) else "Wrong" for i in res}   #add elements to the dictionary
      for i in self.Resources:                                                                            #for all elements of the dictionary
          if type(self.Resources[i]) != int:                                                              #if type of value of ith resourse is not int
              print("Wrong Data")                                                                         #print the message
              self.Resources.clear()                                                                      #and clear the dictionary
              return

  def changeResources(self, NameOfResource, Value):                             #declaration of method
      """Method changes value of the resourse NameOfResource by Value"""
      if NameOfResource in self.Resources:                                      #if NameOfResource is contained in dictionary
          self.Resources[NameOfResource] = Value                                #value of resource changes by value
          return
      self.Resources[NameOfResource] = Value                                    #value of resource changes by value

  def DeleteResources(self, NameOfResource):                                    #declaration of the method
      """Method delets resource NameOfResource"""
      if NameOfResource in self.Resources:                                      #if if NameOfResource is contained in dictionary "Resources"
          self.Resources.pop(NameOfResource)                                    #delete resource from dictionary
      else:                                                                     #else
          print("Resource is not found")                                        #print the message


#поставляет ресурсы
class ResourceFactory(Factory):                                                 
  Class extends from Factory
  Field:
      - _Factories{} - contains info about UserFactories
      - _Type - contains a str with name of Type
  Methods:
      - DeleteFactory() - delete the Factory with cheking
      - GetFullInfo() - print all info about field of the class
  Factories = {}
  Type = "Resource"

  def __del__(self):
        """Delete the Factory, if no one other UserFactories depends on it"""
        if not all([self.Factories[i]==0 for i in self.Factories]):
            print("Resources cant be deleted because some UserFactories depend on it")
        else:
            print(self.Type, self.Name, ' is deleted')


  def GetFullInfo(self):                                                              #declaration of the Method
      Print Name , Type , Resources and Factories
      print('name ', self.Name)
      print('type ', self.Type)
      print('free resources ',
            {i: self.Resources[i] for i in self.Resources if (self.Resources != 0) or (self.Type == "Resource")})
      print('Factories ', self.Factories)
      print('\n\n')

#потребляет ресурсы
class UserFactory(Factory):
  Class extends from Factory
  Field:
      - Type - contains a str with name of Type
  Methods:
      - CreateFactory(self, res) - creates new factory
      - DeleteFactory(self) - delete the Factory with cheking
      - GetFullInfo(self) - print all info about factory: Name, type, used resources and Provider 
      
  Type = "Factory"
  def CreateFactory(self, res):                                                     #declaration of the Method
      if "Factory" == self.Type:                                                    #Type is "Factory"
          if not self.Name in res.Factories:                                        #if NameOfResource is not contained in dictionary
              res.Factories[self.Name] = 0                                          #the number of factories at the resource is 0
          if (all([False if ((DictSub(res.Resources, self.Resources))[i] < 0)       #if enough resources
                    else True for i in (DictSub(res.Resources, self.Resources))])): #if enough resources
              print("Object", self.Name, "is created")                              #print the message
              res.Resources = DictSub(res.Resources, self.Resources)                #Sub the resources that Factory provides
              self.Provider = res                                                   #Provider is res
              res.Factories[self.Name] = res.Factories[self.Name] + 1               #for add 1 to the number of Factories
          else:                                                                     #else
#########################################################################################
              self.Provider = res
              #self.Provider = res                                                   #Provider is res
              print("Object", self.Name, "is not created")                           #print the message 
              

  def __del__(self):    
        """Delete the UserFactory, if it exists"""
        if (self.Provider.Factories[self.Name] < 1):
            print("Factory" , self.Name , "cant be deleted, because it doesn't exists")
            return
        else:
            self.Provider.Resources = DictPlus(self.Provider.Resources, self.Resources)
            self.Provider.Factories[self.Name] = self.Provider.Factories[self.Name] - 1
            print(self.Type, self.Name, ' is deleted')

  def GetFullInfo(self):
      """Print Name , Type , used Resources and Provider"""
      print('name ', self.Name)
      print('type ', self.Type)
      print('used resources ',
            {i: self.Resources[i] for i in self.Resources if (self.Resources != 0) or (self.Type == "Resource")})
      print('Provider ', self.Provider.Name)
      print()

#когда удаляется потребитель, то поставщику возвращаются ресурсы
def DictPlus(a, b):             #add resources to the Provider
    l = {}                      #create new dictionary
    for i in b:                 #for all elements in Factory
        if not i in a:          #if element is not contained in Provider
            a[i] = 0            #value of Resource = 0 (for Provider)
    for i in a:                 #for all elements in Provider
        if not i in b:          #if element is not contained in Factory
            b[i] = 0            #value of Resource = 0 (for Factory)
        l[i] = a[i] + b[i]      #ith element of l = ith element of a + ith element of b
    return l                    #return the result

#когда создается новый потребитель ресурсов, у поставщика они отнимаются
def DictSub(a, b):            #sub resources from the Provider    
    l = {}                    #create new dictionary
    for i in b:               #for all elements in Factory
        if not i in a:        #if element is not contained in Provider
            a[i] = 0          #value of Resource = 0 (for Provider)
    for i in a:               #for all elements in Provider
        if not i in b:        #if element is not contained in Factory
            b[i] = 0          #value of Resource = 0 (for Factory)
        l[i] = a[i] - b[i]    #ith element of l = ith element of a - ith element of b
    return l                  #return the result


